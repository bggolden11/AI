public class Moves {
    double value;
    char d;

    public Moves(double value, char d){
        this.value = value;

        this.d = d;
    }
//    public int compareTo(Moves compareMoves) {
//
//        double compareQuantity = ((Moves) compareMoves).value;
//
//        //ascending order
//        return this.value - compareQuantity;
//
//        //descending order
//        //return compareQuantity - this.quantity;
//
//    }
}
